export interface AptugoEvent extends React.MouseEvent {
  element?: any
}
