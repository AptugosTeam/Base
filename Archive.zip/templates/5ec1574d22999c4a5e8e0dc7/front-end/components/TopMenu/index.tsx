import TopMenu, { AptugoMenuItem } from './TopMenu'

export const TopMenuItem = AptugoMenuItem
export default TopMenu