import AptugoFileUpload from './FileUpload'

export default AptugoFileUpload