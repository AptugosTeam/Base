import AddDialog from './Dialog'

export default AddDialog
