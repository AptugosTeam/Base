module.exports = {
  url: '{{ settings.dbconnectstring | raw }}'
}
